=================================================================================
Title: A Near-Infrared Spectral Library of Very Young Brown Dwarfs and
Planetary-Mass Objects in the Orion Nebula Cluster
Authors: E. Manjavacas, M. Gennaro, S. Betti, L. Pueyo, W. O. Balmer, M. Robberto
=================================================================================
Description of contents: The package contains the 1D spectra of 25 brown dwarfs
planetary-mass objects.

File Name                   Object identifier    RA (deg)       DEC (Deg)
---------                   -----------------   ---------       ---------

spectrum_object_1339.txt    1339                83.87163278	    -5.42179123
spectrum_object_1376.txt    1376                83.77932948     -5.41683643
spectrum_object_1386.txt    1386                83.76937999     -5.43057666
spectrum_object_1436.txt    1436                83.82756381     -5.44209034
spectrum_object_1549.txt    1549                83.75503092     -5.42337210
spectrum_object_1572.txt    1572                83.76288214     -5.42676104
spectrum_object_255.txt     255                 83.77999388     -5.48822882
spectrum_object_262.txt     262                 83.77654681     -5.48144079
spectrum_object_3155.txt    3155                83.86960570     -5.32384671
spectrum_object_3238.txt    3238                83.82993951     -5.31090854
spectrum_object_3241.txt    3241                83.80120292     -5.29723920
spectrum_object_3251.txt    3251                83.83086549     -5.28534493
spectrum_object_3253.txt    3253                83.82259091     -5.28678238
spectrum_object_3256.txt    3256                83.81190488     -5.29820963
spectrum_object_3300.txt    3300                83.86052469	    -5.29774695
spectrum_object_3307.txt    3307                83.85833662     -5.32031533
spectrum_object_3311.txt    3311                83.85787387     -5.28772208
spectrum_object_333.txt     333                 83.78237448     -5.45448142
spectrum_object_334.txt     334                 83.77405342	    -5.452142632
spectrum_object_335.txt     335                 83.76552335     -5.44101921
spectrum_object_3382.txt    3382                83.79897687	    -5.281037032
spectrum_object_3385.txt    3385                83.81244898     -5.28040512
spectrum_object_363.txt     363                 83.85220493	    -5.49394269
spectrum_object_365.txt     365                 83.83851456	    -5.473400529
spectrum_object_366.txt     366                 83.83709122     -5.50135968
spectrum_object_367.txt     367                 83.84238974    	-5.462427854
spectrum_object_372.txt     372                 83.83379331     -5.48769436
spectrum_object_379.txt     379                 83.82282938     -5.47746217
spectrum_object_442.txt     442                 83.84664424     -5.50015704
spectrum_object_469.txt     469                 83.82622430     -5.46586584
spectrum_object_471.txt     471                 83.83463471     -5.45185125
spectrum_object_473.txt     473                 83.83997125	    -5.455875884
spectrum_object_833.txt     833                 83.78670799     -5.51599523
spectrum_object_884.txt     884                 83.79399059	    -5.503202612

System requirements: None.

Additional comments: All of the files are in machine readable format. The
top provides a meta-data header describing the contents while the formatted
data is below. Each file has 3 columns, wavelength (microns), flux
density (erg/s/cm2/micron), and the uncertainty in the flux density (erg/s/cm2/micron).

================================================================================
